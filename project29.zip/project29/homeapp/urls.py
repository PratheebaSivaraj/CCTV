from django.urls import path
from.import views
urlpatterns=[
    path('',views.homepage,name="home"),
    path('cctvdetails',views.loginpage,name="loginpage"),
        path('logout_page',views.logoutpage,name="logoutpage")
    
                ]