from django.shortcuts import render,redirect
from django.contrib.auth.models import User,auth
def homepage(request): 
    if request.method=="POST":
        username=request.POST['uname']
        password=request.POST['passw_']
        user=auth.authenticate(username=username,password=password)
        #if username and password is wrong it returns None
        if user is not None:
            auth.login(request, user)
            return redirect("loginpage")
        else:
            return redirect("home")
    else:
        return render(request,'index.html')
def loginpage(request):
    return render(request,'login.html')

def logoutpage(request):
    auth.logout(request)
    return redirect("home")